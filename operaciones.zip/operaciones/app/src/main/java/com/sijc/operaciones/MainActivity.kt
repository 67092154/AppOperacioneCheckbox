package com.sijc.operaciones

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener{
            if(suma.isChecked)

                resultado.text = "El Resultado es: ${num1.text.toString().toInt() + num2.text.toString().toInt()}"
            if(resta.isChecked)
                resultado.text = "El Resultado es: ${num1.text.toString().toInt() - num2.text.toString().toInt()}"
            if(multiplicasion.isChecked)
                resultado.text = "El Resultado es: ${num1.text.toString().toInt() * num2.text.toString().toInt()}"
            if(division.isChecked)
                resultado.text = "El Resultado es: ${num1.text.toString().toInt() / num2.text.toString().toInt()}"
        }
    }
}